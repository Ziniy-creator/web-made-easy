let large = document.getElementById("showcaseImage");
let thumbnails = document.querySelectorAll(".thumbnails");


for(let index = 0; index < thumbnails.length; index++){
    thumbnails[index].addEventListener("click", (picture)=>{

        large.setAttribute("src", picture.target.src);

    });

}
